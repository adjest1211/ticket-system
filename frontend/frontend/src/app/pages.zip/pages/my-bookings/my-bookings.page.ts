import { Component, OnInit } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';

import {
  IonHeader,
  IonToolbar,
  IonTitle,
  IonContent,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonButton,
  IonBadge
} from '@ionic/angular';

import { BookingService } from '../../services/booking';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-my-bookings',
  standalone: true,
  templateUrl: './my-bookings.page.html',
  imports: [
    CommonModule,
    DatePipe,
    RouterLink,
    IonHeader,
    IonToolbar,
    IonTitle,
    IonContent,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonButton,
    IonBadge
  ]
})
export class MyBookingsPage implements OnInit {

  bookings: any[] = [];
  loading = false;
  errorMessage = '';

  constructor(
    private bookingService: BookingService,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.loadBookings();
  }

  loadBookings() {

    const userId = this.authService.getUserId();

    if (!userId) {
      this.errorMessage = 'Please log in first.';
      return;
    }

    this.loading = true;
    this.errorMessage = '';

    this.bookingService.getMyBookings(userId).subscribe({

      next: (response) => {
        this.bookings = response;
        this.loading = false;
      },

      error: (error) => {
        console.error('Booking loading error:', error);
        this.errorMessage = 'Unable to load your bookings.';
        this.loading = false;
      }

    });

  }

}